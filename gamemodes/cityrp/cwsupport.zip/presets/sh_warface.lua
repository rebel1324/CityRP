
PLUGIN.gunData.ma85_wf_smg25 = {
	holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,0),
		pos = Vector(4, -15, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 2000,
}
PLUGIN.gunData.ma85_wf_smg26 = {
	holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,0),
		pos = Vector(4, -15, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3300,
}
PLUGIN.gunData.ma85_wf_smg17 = {
	holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,0),
		pos = Vector(4, -15, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 2700,
}
PLUGIN.gunData.ma85_wf_smg33 = {
	holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,0),
		pos = Vector(4, -15, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 2000,
}
PLUGIN.gunData.ma85_wf_smg35 = {
	holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,0),
		pos = Vector(4, -15, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 2800,
}
PLUGIN.gunData.ma85_wf_smg31 = {
	holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,0),
		pos = Vector(4, -15, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 4000,
}
PLUGIN.gunData.ma85_wf_smg41 = {
	holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,0),
		pos = Vector(4, -20, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 2000,
}
PLUGIN.gunData.ma85_wf_smg10 = {
	holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,0),
		pos = Vector(4, -15, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 2000,
}
PLUGIN.gunData.ma85_wf_shg13 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,0),
		pos = Vector(4, -15, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_shg38 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -33, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_smg18 = {
	holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,0),
		pos = Vector(4, -5, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3000,
}

PLUGIN.gunData.ma85_wf_smg37 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,0),
		pos = Vector(4, -5, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 2400,
}

PLUGIN.gunData.ma85_wf_sr41 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,0),
		pos = Vector(4, -15, -3),
	},
	slot = 2,
	width = 4,
	height = 2,
	price = 4000,
}

PLUGIN.gunData.ma85_wf_shg38 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -33, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_shg05 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -28, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_shg07 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -23, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_shg41 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -0, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_shg03 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -15, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_ar04 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -18, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_ar22 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -18, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_ar22_old = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -18, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_ar03 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -23, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_ar07 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -0, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_ar25 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -20, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_ar11 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -20, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_ar06 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -20, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_ar24 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -20, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_ar12 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -28, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_mg07 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -18, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_ar26 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -18, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_ar41 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -20, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_ar01 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -15, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_sr04 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -25, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}


PLUGIN.gunData.ma85_wf_sr39 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, 0, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}


PLUGIN.gunData.ma85_wf_sr31 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, 0, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}


PLUGIN.gunData.ma85_wf_sr07 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -30, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}


PLUGIN.gunData.ma85_wf_sr35 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -33, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}


PLUGIN.gunData.ma85_wf_sr09 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -20, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_sr41 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -0, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_sr37 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -25, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_sr34 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -20, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}

PLUGIN.gunData.ma85_wf_sr12 = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -15, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}


PLUGIN.gunData.ma85_wf_sr12_blue = {
		holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -15, -3),
	},
	slot = 2,
	width = 3,
	height = 2,
	price = 3500,
}


PLUGIN.gunData.ma85_wf_pt22 = {
	holster = {
		bone = "ValveBiped.Bip01_R_Thigh",
		ang = Angle(-90, -90,0),
		pos = Vector(0, 10, -4),
	},
	slot = 1,
	price = 1200,
}

PLUGIN.gunData.ma85_wf_pt21 = {
	holster = {
		bone = "ValveBiped.Bip01_R_Thigh",
		ang = Angle(-90, -90,0),
		pos = Vector(0, 10, -4),
	},
	slot = 1,
	price = 2300,
}

PLUGIN.gunData.ma85_wf_pt41_ww2 = {
	holster = {
		bone = "ValveBiped.Bip01_R_Thigh",
		ang = Angle(-90, -90,0),
		pos = Vector(0, 10, -4),
	},
	slot = 1,
	price = 2000,
}

PLUGIN.gunData.ma85_wf_pt27 = {
	holster = {
		bone = "ValveBiped.Bip01_R_Thigh",
		ang = Angle(-90, -90,0),
		pos = Vector(0, 10, -4),
	},
	slot = 1,
	price = 1000,
}

PLUGIN.gunData.ma85_wf_pt14 = {
	holster = {
		bone = "ValveBiped.Bip01_R_Thigh",
		ang = Angle(-90, -90,0),
		pos = Vector(0, 10, -4),
	},
	slot = 1,
	price = 2000,
}

PLUGIN.gunData.ma85_wf_pt10 = {
	holster = {
		bone = "ValveBiped.Bip01_R_Thigh",
		ang = Angle(-90, -90,0),
		pos = Vector(0, 10, -4),
	},
	slot = 1,
	price = 1500,
}

PLUGIN.gunData.ma85_wf_pt04 = {
	holster = {
		bone = "ValveBiped.Bip01_Spine2",
		ang = Angle(180, 90,10),
		pos = Vector(4, -15, -3),
	},
	slot = 1,
	price = 1600,
}
